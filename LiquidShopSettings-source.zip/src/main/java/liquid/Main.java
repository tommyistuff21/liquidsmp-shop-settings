package liquid;
import java.util.*;
import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.view.AnvilView;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.*;

public final class Main extends JavaPlugin implements Listener {
  private final Set<String> vision = new HashSet<>();
  private List<Material> catalog;
  private static final Set<String> RESTRICTED = Set.of("BEDROCK","BARRIER","COMMAND_BLOCK","CHAIN_COMMAND_BLOCK","REPEATING_COMMAND_BLOCK","COMMAND_BLOCK_MINECART","STRUCTURE_BLOCK","STRUCTURE_VOID","JIGSAW","DEBUG_STICK","LIGHT","KNOWLEDGE_BOOK","SPAWNER","TRIAL_SPAWNER","VAULT","END_PORTAL_FRAME","REINFORCED_DEEPSLATE","TEST_BLOCK","TEST_INSTANCE_BLOCK");
  private static class Menu implements InventoryHolder {
    Inventory inv; String kind, query; int page; Material item; List<Material> results;
    Menu(String k,String q,int p){kind=k;query=q;page=p;}
    public Inventory getInventory(){return inv;}
  }
  @Override public void onEnable(){
    saveDefaultConfig(); vision.addAll(getConfig().getStringList("night-vision"));
    catalog=Arrays.stream(Material.values()).filter(m->!m.isLegacy() && m.isItem() && !m.isAir()).filter(m->getConfig().getBoolean("allow-admin-items") || !RESTRICTED.contains(m.name())).sorted(Comparator.comparing(Material::name)).toList();
    getServer().getPluginManager().registerEvents(this,this);
    getServer().getScheduler().runTaskTimer(this,()->{for(Player p:Bukkit.getOnlinePlayers()) if(vision.contains(p.getUniqueId().toString())) apply(p);},1L,100L);
  }
  @Override public boolean onCommand(CommandSender s,Command c,String l,String[] a){
    if(!(s instanceof Player p)){s.sendMessage("Players only.");return true;}
    if(c.getName().equals("settings")){settings(p);return true;}
    if(p.hasPermission("liquidshop.use")) shop(p,String.join(" ",a),0); return true;
  }
  private ItemStack icon(Material m,String name,String... lore){ItemStack i=new ItemStack(m);ItemMeta meta=i.getItemMeta();meta.setDisplayName(name);meta.setLore(Arrays.asList(lore));i.setItemMeta(meta);return i;}
  private void shop(Player p,String q,int page){
    if(!p.hasPermission("liquidshop.use"))return;
    Menu h=new Menu("shop",q,page); String term=q.toLowerCase(Locale.ROOT).replace('_',' ').trim();
    h.results=catalog.stream().filter(m->m.name().toLowerCase(Locale.ROOT).replace('_',' ').contains(term)).toList();
    int max=Math.max(0,(h.results.size()-1)/45);h.page=Math.max(0,Math.min(page,max));
    h.inv=Bukkit.createInventory(h,54,"§2LiquidSMP §8| §0Shop "+(h.page+1)+"/"+(max+1));
    for(int i=0;i<45 && h.page*45+i<h.results.size();i++)h.inv.setItem(i,new ItemStack(h.results.get(h.page*45+i)));
    if(h.page>0)h.inv.setItem(45,icon(Material.ARROW,"§aPrevious page"));
    h.inv.setItem(48,icon(Material.BARRIER,"§cClear search"));h.inv.setItem(49,icon(Material.OAK_SIGN,"§aSearch items","§7Click to type a name"));
    h.inv.setItem(50,icon(Material.PAPER,"§a"+h.results.size()+" results","§7Search: "+q));
    if(h.page<max)h.inv.setItem(53,icon(Material.ARROW,"§aNext page"));p.openInventory(h.inv);
  }
  private void search(Player p,Menu old){Menu h=new Menu("search",old.query,old.page);h.inv=Bukkit.createInventory(h,InventoryType.ANVIL,"§2Search items");h.inv.setItem(0,icon(Material.PAPER,"Search"));p.openInventory(h.inv);}
  @EventHandler public void prepare(PrepareAnvilEvent e){if(e.getInventory().getHolder() instanceof Menu h && h.kind.equals("search"))e.setResult(icon(Material.PAPER,"§aClick to search"));}
  private void quantity(Player p,Menu old,Material m){Menu h=new Menu("quantity",old.query,old.page);h.item=m;h.inv=Bukkit.createInventory(h,27,"§2LiquidSMP §8| §0Quantity");h.inv.setItem(4,new ItemStack(m));h.inv.setItem(11,icon(Material.LIME_DYE,"§aGet 1"));h.inv.setItem(13,icon(Material.LIME_DYE,"§aGet 16"));h.inv.setItem(15,icon(Material.LIME_DYE,"§aGet 64"));h.inv.setItem(22,icon(Material.ARROW,"§aBack"));p.openInventory(h.inv);}
  private void settings(Player p){Menu h=new Menu("settings","",0);h.inv=Bukkit.createInventory(h,27,"§2LiquidSMP §8| §0Settings");boolean mobs=Boolean.TRUE.equals(p.getWorld().getGameRuleValue(GameRule.DO_MOB_SPAWNING));boolean nv=vision.contains(p.getUniqueId().toString());h.inv.setItem(11,icon(Material.ZOMBIE_SPAWN_EGG,"§aMob spawning: "+(mobs?"§aON":"§cOFF"),"§7Current world • Admin only"));h.inv.setItem(15,icon(Material.GOLDEN_CARROT,"§aNight vision: "+(nv?"§aON":"§cOFF"),"§7Personal setting"));p.openInventory(h.inv);}
  private void apply(Player p){p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION,-1,0,false,false,false));}
  private void later(Player p,Runnable r){Bukkit.getScheduler().runTask(this,()->{if(p.isOnline())r.run();});}
  @EventHandler public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
  @EventHandler public void click(InventoryClickEvent e){
    if(!(e.getView().getTopInventory().getHolder() instanceof Menu h))return;e.setCancelled(true);
    if(!(e.getWhoClicked() instanceof Player p))return;int slot=e.getRawSlot();if(slot<0||slot>=h.inv.getSize())return;
    if(!h.kind.equals("settings")&&!p.hasPermission("liquidshop.use"))return;
    switch(h.kind){
      case "shop" -> {if(slot<45 && h.page*45+slot<h.results.size()){Material m=h.results.get(h.page*45+slot);later(p,()->quantity(p,h,m));}else if(slot==45&&h.page>0)later(p,()->shop(p,h.query,h.page-1));else if(slot==53)later(p,()->shop(p,h.query,h.page+1));else if(slot==48)later(p,()->shop(p,"",0));else if(slot==49)later(p,()->search(p,h));}
      case "search" -> {if(slot==2 && e.getView() instanceof AnvilView av){String q=av.getRenameText();later(p,()->shop(p,q==null||q.equals("Search")?"":q,0));}}
      case "quantity" -> {if(slot==22){later(p,()->shop(p,h.query,h.page));return;}int n=slot==11?1:slot==13?16:slot==15?64:0;if(n==0)return;int delivered=0;while(n>0){int count=Math.min(n,h.item.getMaxStackSize());var remaining=p.getInventory().addItem(new ItemStack(h.item,count));int missed=remaining.values().stream().mapToInt(ItemStack::getAmount).sum();delivered+=count-missed;n-=count;if(missed>0)break;}p.sendMessage("§aReceived "+delivered+" "+h.item.name().toLowerCase(Locale.ROOT).replace('_',' ')+".");}
      case "settings" -> {if(slot==11){if(!p.hasPermission("liquidshop.mobs")){p.sendMessage("§cOnly admins can change world mob spawning.");return;}World w=p.getWorld();w.setGameRule(GameRule.DO_MOB_SPAWNING,!Boolean.TRUE.equals(w.getGameRuleValue(GameRule.DO_MOB_SPAWNING)));later(p,()->settings(p));}else if(slot==15){String id=p.getUniqueId().toString();if(vision.remove(id))p.removePotionEffect(PotionEffectType.NIGHT_VISION);else{vision.add(id);apply(p);}getConfig().set("night-vision",new ArrayList<>(vision));saveConfig();later(p,()->settings(p));}}
    }
  }
}
